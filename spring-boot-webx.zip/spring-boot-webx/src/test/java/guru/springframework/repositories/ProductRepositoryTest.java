package guru.springframework.repositories;

import guru.springframework.configuration.RepositoryConfiguration;
import guru.springframework.domain.Product;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = {RepositoryConfiguration.class})
@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:data-h2.sql")
public class ProductRepositoryTest {

    private ProductRepository productRepository;

    @Autowired
    public void setProductRepository(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }


    @Test
    public void testData(){
    	 
    	 
Integer produitId = 1;
        //fetch from DB
        Product fetchedProduct = productRepository.findOne(produitId);

        //should not be null
        assertNotNull(fetchedProduct);

        //should equal
        assertEquals(fetchedProduct.getId(), produitId);
        assertEquals(fetchedProduct.getDescription(), "descriptionx 1");
    }

    
    
    @Test
    @Ignore
    public void testSaveProduct(){
    	 
    	Product product1 = saveProduct("Description 1 test save product",new BigDecimal("18.95"),"1234");
        
        saveProduct("Description 2 test save product",new BigDecimal("95.14"),"157");

        //fetch from DB
        Product fetchedProduct = productRepository.findOne(product1.getId());

        //should not be null
        assertNotNull(fetchedProduct);

        //should equal
        assertEquals(product1.getId(), fetchedProduct.getId());
        assertEquals(product1.getDescription(), fetchedProduct.getDescription());

        //update description and save
        fetchedProduct.setDescription("New Description");
        productRepository.save(fetchedProduct);

        //get from DB, should be updated
        Product fetchedUpdatedProduct = productRepository.findOne(fetchedProduct.getId());
        assertEquals(fetchedProduct.getDescription(), fetchedUpdatedProduct.getDescription());

        //verify count of products in DB
        long productCount = productRepository.count();
        assertEquals(productCount, 3);

        //get all products, list should only have one
        Iterable<Product> products = productRepository.findAll();

        int count = 0;

        for(Product p : products){
        	 System.out.println(p.toString());
            count++;
        }

        assertEquals(count, 3);
        
        
        
        
    }

	private Product saveProduct(String descr, BigDecimal price, String idProduct) {
		 //setup product
        Product product = new Product();
        product.setDescription(descr);
        product.setPrice(price);
        product.setProductId(idProduct);        

        //save product, verify has ID value after save
        assertNull(product.getId()); //null before save
        productRepository.save(product);
        assertNotNull(product.getId()); //not null after save
        
        return product;
	}
	
	
}
