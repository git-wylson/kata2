package com.wd;
import java.util.*;

public class IsoContest0 {
public static void main( String[] argv ) throws Exception {
        String  line;
        Scanner sc = new Scanner(System.in);
        String startS=sc.nextLine();
        int start=Integer.parseInt(startS);
        int numLines = Integer.parseInt(sc.nextLine());
        int trancount = 0;
        for (int i = 0; i < numLines; i++){
            /*Read the input here and perform the calculations*/
            String val = sc.nextLine();
            int debit = Integer.parseInt(val);
            start = start + debit;
        }
        System.out.println(start);
    }
}
