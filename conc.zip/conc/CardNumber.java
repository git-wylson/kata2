package com.wd;

import java.util.*;

public class CardNumber /*IsoContest*/ {
public static void main( String[] argv ) throws Exception {
    Scanner sc = new Scanner(System.in);
    String cadNumer;  
	
	 while(sc.hasNextLine()) {
		 cadNumer = sc.nextLine();
		 System.out.println("Card is valid? : "+calculo(cadNumer));
	 }
 
    }

private static boolean calculo(String numCard){
	
	int [] digits = new int[16];
	int x = 2;
	int sum = 0;
	String numberCard;
	
	if(numCard!=null && numCard.replaceAll("\\s+", "").length()==16){
		numberCard = numCard.replaceAll("\\s+", "");
		for(int i=0 ; i<15;i++){
			if(i%2==0){
			x =2;
			}else {
			x=1;	
			}
			int digit = Integer.parseInt(""+numberCard.charAt(i))*x;
			
			if(digit>9){
				digits[i] = digit - 9;
			}else{
				digits[i] = digit;
			}
		}
		
		for(int j=0;j<15;j++){
			sum += digits[j];
		}
		
		System.out.println(sum);
		
		int key = Integer.parseInt(""+numberCard.charAt(numberCard.length()-1));
		if((sum+key)%10==0) {
			return true;
		}
		else return false;
	}
	
	return false;
	
}

}

