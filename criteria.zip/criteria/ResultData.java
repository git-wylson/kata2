package fr.wd.transport.common.model;

import java.util.List;

public class ResultData<T> {

	private List<T> data;
	private Pagination pagination;

	public List<T> getData() {
		return data;
	}

	public void setData(final List<T> data) {
		this.data = data;
	}

	public Pagination getPagination() {
		return pagination;
	}

	public void setPagination(final Pagination pagination) {
		this.pagination = pagination;
	}

	@Override
	public String toString() {
		return "ResultData [data=" + data + ", pagination=" + pagination + "]";
	}
}
