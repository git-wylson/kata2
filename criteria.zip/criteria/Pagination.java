package fr.wd.transport.common.model;

//import javax.validation.constraints.Min;
//import javax.validation.constraints.NotNull;

import org.codehaus.jackson.annotate.JsonIgnore;

public class Pagination {

	// @Min(value = 1, message = "{recherche.pagination.parPage.value}")
	// @NotNull(message = "{recherche.pagination.parpage.mandatory}")
	private Long parPage = Long.valueOf(10);

	// @Min(value = 1, message = "{recherche.pagination.page.value}")
	// @NotNull(message = "{recherche.pagination.page.mandatory}")
	private Long page = Long.valueOf(1);

	private Long total;

	public Pagination() {
	}

	public Pagination(final Long parPage, final Long page) {
		this.parPage = parPage;
		this.page = page;
	}

	public Long getParPage() {
		return parPage;
	}

	public void setParPage(final Long parPage) {
		this.parPage = parPage;
	}

	public Long getPage() {
		return page;
	}

	public void setPage(final Long page) {
		this.page = page;
	}

	public Long getTotal() {
		return total;
	}

	public void setTotal(Long total) {
		this.total = total;
	}

	// @JsonIgnore :permet d'ignorer cette operation lors de serialisation object en json
	@JsonIgnore
	public Long getOffset() {
		if (page == null || parPage == null || page <= 0 || parPage <= 0) {
			return 0L;
		}
		return (page - 1) * parPage;
	}

	@Override
	public String toString() {
		return "Pagination [parPage=" + parPage + ", page=" + page + ", total=" + total + "]";
	}
}
