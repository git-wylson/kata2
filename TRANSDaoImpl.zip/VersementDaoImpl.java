package com.wd.transport.dao.impl;

import static com.wd.transport.model.Versement.CALCULER_SOMME_VERSEMENT;
import static com.wd.transport.model.Versement.DATE_DEBUT_VERSEMENT;
import static com.wd.transport.model.Versement.DATE_FIN_VERSEMENT;
import static com.wd.transport.model.Versement.FIND_ALL_VERSEMENT;

import java.util.Date;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.persistence.TypedQuery;

import com.wd.transport.dao.IVersementDao;
import com.wd.transport.model.Versement;

@ApplicationScoped
public class VersementDaoImpl extends TRANSDaoImpl<Versement> implements IVersementDao {

	public VersementDaoImpl() {
		entityClass = Versement.class;
	}

	public List<Versement> findAll() {
		TypedQuery<Versement> query = entityManager.createNamedQuery(FIND_ALL_VERSEMENT, Versement.class);
		List<Versement> results = query.getResultList();
		return results;
	}

	@Override
	public Integer calculateSumVersement(Date dateDebut, Date dateFin) {
		TypedQuery<Long> query = entityManager.createNamedQuery(CALCULER_SOMME_VERSEMENT, Long.class);
		query.setParameter(DATE_DEBUT_VERSEMENT, dateDebut);
		query.setParameter(DATE_FIN_VERSEMENT, dateFin);
		Long somme = query.getSingleResult();
		if (somme != null) {
			return somme.intValue();
		}
		return null;
	}
}
