package com.wd;
import java.util.*;

public class IsoContest {
public static void main( String[] argv ) throws Exception {
	 System.out.println("Start");
		String  line;
		int noOfPeople=0;
        Map<Integer,Integer> hourMap = new HashMap<>();
        
        Scanner sc = new Scanner(System.in);
        
        line = sc.nextLine();
        
        noOfPeople = Integer.parseInt(line);
               
        for(int i=0; i< noOfPeople; i++){
	        if(sc.hasNextLine()) {
	        	line = sc.nextLine();
	        	String[] times = line.split(" ");
	        	int arrival = Integer.parseInt(times[0]);
	        	int dep = Integer.parseInt(times[1]);
	        	for(int x=arrival; x<dep; x++){
	        		int count=1;
	        		if(hourMap.containsKey(x))
	        			count = hourMap.get(x) + 1;
	        		
	        		hourMap.put(x, count);
	        	}
	        }
		}
        
        ArrayList<Integer> maxHourList = new ArrayList<Integer>();
        int max=-1;
        for(Integer key : hourMap.keySet()){
        	if(hourMap.get(key) > max){
        		max = hourMap.get(key);
        	}
        }
        
        for(Integer key : hourMap.keySet()){
        	if(hourMap.get(key) == max){
        		maxHourList.add(key);
        	}
        }
        
        Collections.sort(maxHourList);
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < maxHourList.size(); i++) {
			sb.append(maxHourList.get(i)+ " ");
		}
        System.out.println(sb.toString().trim());
        //IsoContestBase.dump("Map", );
    }
}
