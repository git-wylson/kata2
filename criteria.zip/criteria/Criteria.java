package fr.wd.transport.common.model;

import java.util.List;
import java.util.Map;

public class Criteria {

	// @Valid
	private Pagination pagination;

	private Map<String, Object> filtres;

	private List<Sort> tri;

	public Pagination getPagination() {
		return pagination;
	}

	public void setPagination(Pagination pagination) {
		this.pagination = pagination;
	}

	public Map<String, Object> getFiltres() {
		return filtres;
	}

	public void setFiltres(Map<String, Object> filtres) {
		this.filtres = filtres;
	}

	public List<Sort> getTri() {
		return tri;
	}

	public void setTri(List<Sort> tri) {
		this.tri = tri;
	}

}
