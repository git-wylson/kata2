package com.wd.transport.model;

import static com.wd.transport.model.Versement.CALCULER_SOMME_VERSEMENT;
import static com.wd.transport.model.Versement.DATE_DEBUT_VERSEMENT;
import static com.wd.transport.model.Versement.DATE_FIN_VERSEMENT;
import static com.wd.transport.model.Versement.FIND_ALL_VERSEMENT;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "tbl_versement_db", schema = "public")
@NamedQueries({
		@NamedQuery(name = FIND_ALL_VERSEMENT, query = "SELECT v FROM Versement v ORDER BY v.id DESC"),
		@NamedQuery(name = CALCULER_SOMME_VERSEMENT, query = "SELECT SUM(v.montantVersement) FROM Versement v WHERE v.dateVersement>=:" + DATE_DEBUT_VERSEMENT
				+ "  AND v.dateVersement <=:" + DATE_FIN_VERSEMENT) })
public class Versement implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String FIND_ALL_VERSEMENT = "findAllVersement";
	public static final String CALCULER_SOMME_VERSEMENT = "calculerSommeVersement";
	public static final String DATE_DEBUT_VERSEMENT = "dateDebut";
	public static final String DATE_FIN_VERSEMENT = "dateFin";

	private Integer id;
	private RessourceHumaine chauffeur;
	private Date dateVersement;
	private Integer montantVersement;
	private Integer litige;
	private Boolean flagSolde;
	private String commentaire;
	private String matriculeVehicule;

	private RessourceHumaine matriculeCreation;

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "versement_id_seq")
	@SequenceGenerator(schema = "public", name = "versement_id_seq", sequenceName = "versement_id_seq", allocationSize = 1)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@OneToOne
	@JoinColumn(name = "identifiant_chauffeur", nullable = false, referencedColumnName = "id")
	public RessourceHumaine getChauffeur() {
		return chauffeur;
	}

	public void setChauffeur(RessourceHumaine chauffeur) {
		this.chauffeur = chauffeur;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "date_versement")
	public Date getDateVersement() {
		return dateVersement;
	}

	public void setDateVersement(Date dateVersement) {
		this.dateVersement = dateVersement;
	}

	@Column(name = "montant_versement", nullable = false)
	public Integer getMontantVersement() {
		return montantVersement;
	}

	public void setMontantVersement(Integer montantVersement) {
		this.montantVersement = montantVersement;
	}

	@Column(name = "litige_versement")
	public Integer getLitige() {
		return litige;
	}

	public void setLitige(Integer litige) {
		this.litige = litige;
	}

	@Column(name = "flag_solde")
	public Boolean getFlagSolde() {
		return flagSolde;
	}

	public void setFlagSolde(Boolean flagSolde) {
		this.flagSolde = flagSolde;
	}

	@Column(name = "commentaire")
	public String getCommentaire() {
		return commentaire;
	}

	public void setCommentaire(String commentaire) {
		this.commentaire = commentaire;
	}

	@OneToOne
	@JoinColumn(name = "login_creation", referencedColumnName = "login")
	public RessourceHumaine getMatriculeCreation() {
		return matriculeCreation;
	}

	public void setMatriculeCreation(RessourceHumaine matriculeCreation) {
		this.matriculeCreation = matriculeCreation;
	}

	@Column(name = "matricule_vehicule")
	public String getMatriculeVehicule() {
		return matriculeVehicule;
	}

	public void setMatriculeVehicule(String matriculeVehicule) {
		this.matriculeVehicule = matriculeVehicule;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Versement other = (Versement) obj;
		if (getId() == null) {
			if (other.getId() != null) {
				return false;
			}
		} else if (!getId().equals(other.getId())) {
			return false;
		}
		return true;
	}

}
