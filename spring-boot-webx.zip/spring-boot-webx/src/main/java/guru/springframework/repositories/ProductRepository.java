package guru.springframework.repositories;

import guru.springframework.domain.Product;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Product, Integer>{
	
//	@Query(value = "SELECT * FROM PRODUCT WHERE NAME = ?1",
//		    countQuery = "SELECT count(*) FROM PRODUCT WHERE NAME = ?1",
//		    nativeQuery = true)
//	Page<Product> findByQuery(String lastname, Pageable pageable);
}
