package fr.bpi.fmg.bcp.util;

import static org.fest.assertions.Assertions.assertThat;

import java.lang.reflect.InvocationTargetException;

import org.junit.Test;

import fr.bpi.fro.model.bcp.EtablissementBcp;
import fr.bpi.fro.model.bcp.EtablissementBcpId;
import fr.bpi.fro.model.bcp.InterlocuteurBcp;

public class ReflectionUtilTest {

	@Test
	public void chargerClePrimaire_ShoudReturnBasicPrimaryKey()
			throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
		// given
		InterlocuteurBcp interlocuteur = new InterlocuteurBcp();
		interlocuteur.setId(2526);

		// when
		Object clePrimaire = ReflectionUtil.getClePrimaireEntite(interlocuteur);

		// then
		assertThat((Integer) clePrimaire).isEqualTo(2526);
	}

	@Test
	public void chargerClePrimaire_ShoudReturnComplexPrimaryKey()
			throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
		// given
		EtablissementBcp etablissement = new EtablissementBcp();
		EtablissementBcpId etablissementId = new EtablissementBcpId();
		etablissementId.setCodeSocieteGestion((short) 1);
		etablissementId.setNumeroRelationAffaire(1234);
		etablissementId.setNumeroEtablissement((short) 2);
		etablissement.setId(etablissementId);

		// when
		Object clePrimaire = ReflectionUtil.getClePrimaireEntite(etablissement);

		// then
		assertThat(clePrimaire).isEqualTo(etablissementId);
	}

}
