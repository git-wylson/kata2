package fr.bpi.fmg.bcp.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Id;

import com.google.common.base.Strings;

public final class ReflectionUtil {

	private static final String GET = "get";

	private ReflectionUtil() {

	}

	public static final Object getClePrimaireEntite(Object entity) {
		Method[] methods = entity.getClass().getMethods();
		for (Method method : methods) {
			if (method.isAnnotationPresent(Id.class) || method.isAnnotationPresent(EmbeddedId.class)) {
				try {
					return method.invoke(entity);
				} catch (IllegalArgumentException e) {
					return null;
				} catch (IllegalAccessException e) {
					return null;
				} catch (InvocationTargetException e) {
					return null;
				}
			}
		}
		return null;
	}

	public static final String getNomDuChampsPossedantAnnotationColumnAvecLaValeur(Class<?> clazzEntity, String valeurAnnotation) {
		if (!Strings.isNullOrEmpty(valeurAnnotation)) {
			Method[] methods = clazzEntity.getMethods();
			for (Method method : methods) {
				if (method.isAnnotationPresent(Column.class)) {
					Column column = method.getAnnotation(Column.class);
					if (valeurAnnotation.equals(column.name())) {
						String champs = soustraireLeGetDuGetter(method);

						return mettreEnMinusculeLaPremiereLettre(champs);
					}
				}
			}
		}
		return null;
	}

	public static final String getNomDuChampsPossedantAnnotationTriAsc(Class<?> clazzEntity) {

		Method[] methods = clazzEntity.getMethods();

		for (Method method : methods) {
			if (method.isAnnotationPresent(TriPar.class)) {
				TriPar tri = method.getAnnotation(TriPar.class);
				if ("ASC".equals(tri.value())) {

					return mettreEnMinusculeLaPremiereLettre(soustraireLeGetDuGetter(method));
				}
			}
		}

		return null;
	}

	private static final String soustraireLeGetDuGetter(Method method) {
		if (method.getName().startsWith(GET)) {
			return method.getName().substring(GET.length());
		}
		return method.getName();
	}

	private static final String mettreEnMinusculeLaPremiereLettre(String champs) {
		Character premiereLettreEnMinuscule = Character.toLowerCase(champs.charAt(0));

		StringBuffer champsModifie = new StringBuffer(premiereLettreEnMinuscule.toString());
		champsModifie.append(champs.substring(1));

		return champsModifie.toString();
	}

}
