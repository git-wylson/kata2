package com.wd.transport.dao.impl;

import javax.persistence.EntityManager;
//import javax.validation.Valid;

import com.wd.transport.dao.GenericDao;

//@ZValidate
public abstract class GenericDaoImpl<T> implements GenericDao<T> {

	protected Class<T> entityClass;

	protected abstract EntityManager getEntityManager();

	// @Override
	public void persist(/* @Valid */T entity) {
		getEntityManager().persist(entity);
	}

	// @Override
	public T merge(T entity) {
		return getEntityManager().merge(entity);
	}

	// @Override
	public T find(Object primaryKey) {
		return getEntityManager().find(entityClass, primaryKey);
	}

	public void remove(T entity) {
		getEntityManager().remove(entity);
	}

	// @Override
	public void refresh(T entity) {
		getEntityManager().refresh(entity);
	}

	// @Override
	public void flush() {
		getEntityManager().flush();
	}

}
