package fr.bpi.fmg.bcp.dao.validator;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import fr.bpi.fmg.bcp.dao.impl.EntityManagerProvider;
import fr.bpi.fmg.bcp.util.ReflectionUtil;

public class ExistsValidator implements ConstraintValidator<Exists, Object> {

	private boolean mandatory;

	@Inject
	@Named(EntityManagerProvider.TRANSPORT)
	protected EntityManager entityManager;

	@Override
	public void initialize(Exists constraintAnnotation) {
		this.mandatory = constraintAnnotation.mandatory();
	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		if (value != null) {
			return entityManager.find(value.getClass(), ReflectionUtil.getClePrimaireEntite(value)) == null ? false : true;
		}
		return !mandatory;
	}

}


//@Exists(message = "erreur de focntion", groups = { CreateValidation.class, UpdateValidation.class })
//private Fonction fonction;

//Class<CreateValidation> groups = CreateValidation.class; 
//Set<ConstraintViolation<EtablissementBcp>> constraintViolations = zValidatorProvider.getValidator().validate(etablissement, groups);