package com.wd.transport.dao.impl;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;

import com.wd.transport.dao.EntityManagerProvider;

public class TRANSDaoImpl<T> extends GenericDaoImpl<T> {

	@Inject
	@Named(EntityManagerProvider.TRANSPORT_PU)
	protected EntityManager entityManager;

	@Override
	protected EntityManager getEntityManager() {
		return entityManager;
	}

}
