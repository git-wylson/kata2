package fr.wd.transport.common.model;

public class Sort {

	private String champ;
	private String type;

	public Sort() {

	}

	public Sort(String champ, String type) {
		this.champ = champ;
		this.type = type;
	}

	public String getChamp() {
		return champ;
	}

	public void setChamp(String champ) {
		this.champ = champ;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
